function dydx =twonode(x,y)
dydx=[y(2) 
        3*y(2)-y(1)];
end