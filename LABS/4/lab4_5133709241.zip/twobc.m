function res=twobc(ya,yb)
res=[ya(1)
            yb(1)-10];
end