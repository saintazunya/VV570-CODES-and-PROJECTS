function res=twobc_(ya,yb)
res=[ya(1)
            y(1)];
end